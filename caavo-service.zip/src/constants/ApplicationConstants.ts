export class ApplicationConstants {

    static readonly SUCCESS: String = 'Success';
    static readonly FAILURE: String = 'Failure';

}