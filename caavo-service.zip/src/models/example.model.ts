import { Schema, model } from 'mongoose';

let schema: Schema = new Schema({
    'docID': String,
    'docType': String,
    'firstName': String,
    'dateOfIssued': String,
    'issuedBy': String,
    'others': String,
    'email': String

});

export default model('Examples', schema);


