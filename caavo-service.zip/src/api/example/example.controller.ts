import { Request, Response, NextFunction } from 'express';
import Example from '../../models/example.model';
import * as winston from 'winston';
import { ExampleDelegate } from '../../delegate/example.delegate';
import { ApplicationConstants } from '../../constants/ApplicationConstants';

export class ExampleController {

    static exampleDelegate: ExampleDelegate = new ExampleDelegate();

    /**
     * Get all
     * @param {*} req
     * @param {*} res
     * @param {*} next
     */
    public static async getAll(req: Request, res: Response, next: NextFunction): Promise<any> {

        try {
            let result = await ExampleDelegate.getAll(req);
            res.send({ 'isSuccess': true, 'document': result });
        } catch (err) {
            winston.error('Internal Server Error ::: ExampleController - getAll', err);
            res.send({
                'isSuccess': false,
                'message': 'Could not get Examples',
                'err': err
            });
        }
    }

    /**
     * Create
     * @param {*} req
     * @param {*} res
     * @param {*} next
     */
    public static async create(req: Request, res: Response, next: NextFunction) {

        try {
            let result = await ExampleDelegate.create(req);
            res.send({ 'isSuccess': true, 'document': result });
        } catch (err) {
            winston.error('Internal Server Error ::: ExampleController - create', err);
            res.send({
                'isSuccess': false,
                'message': 'Could not create Example',
                'err': err
            });
        }
    }

    /**
     * Update
     * @param {*} req
     * @param {*} res
     * @param {*} next
     */
    public static async update(req: Request, res: Response, next: NextFunction) {

        try {
            let result = await ExampleDelegate.update(req);
            res.send({ 'isSuccess': true, 'message': result });
        } catch (err) {
            winston.error('Internal Server Error ::: ExampleController - update', err);
            res.send({
                'isSuccess': false,
                'message': 'Could not update Example',
                'err': err
            });
        }
    }

    /**
     * Delete
     * @param {*} req
     * @param {*} res
     * @param {*} next
     */
    public static async delete(req: Request, res: Response, next: NextFunction) {

        try {
            let result = await ExampleDelegate.delete(req);
            res.send({ 'isSuccess': true, 'message': ApplicationConstants.SUCCESS });
        } catch (err) {
            winston.error('Internal Server Error ::: ExampleController - delete', err);
            res.send({
                'isSuccess': false,
                'message': 'Could not delete Example',
                'err': err
            });
        }
    }

}