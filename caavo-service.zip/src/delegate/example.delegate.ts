import { Request } from 'express';
import * as winston from 'winston';
import Example from '../models/example.model';

export class ExampleDelegate {

    public static async getAll(req: Request): Promise<any> {
        // Get data
        try {
            let result = await Example.find().exec();
            return Promise.resolve(result);
        } catch (err) {
            winston.error('Internal Server Error ::: ExampleDelegate - getAll', err);
            return Promise.reject(err);
        }
    }

    public static async create(req: Request): Promise<any> {

        try {
            // Create model
            let example = new Example({
                'docID': req.body.docID,
                'docType': req.body.docType,
                'firstName': req.body.firstName,
                'dateOfIssued': req.body.dateOfIssued,
                'issuedBy': req.body.issuedBy,
                'others': req.body.others,
                'email': req.body.email

            });

          
            // Save
            await example.save();
            return Promise.resolve(example);
        } catch (err) {
            winston.error('Internal Server Error ::: ExampleDelegate - create', err);
            return Promise.reject(err);
        }
    }

    public static async update(req: Request): Promise<any> {

        try {
            let result = await Example.update({ 'docID': req.body.docID }, req.body).exec();
            return Promise.resolve(result);
        } catch (err) {
            winston.error('Internal Server Error ::: ExampleDelegate - update', err);
            return Promise.reject(err);
        }
    }

    public static async delete(req: Request): Promise<any> {
        try {
            winston.error('',req.params.id)
            let result = await Example.remove({ '_id': req.params._id }).exec();
            return Promise.resolve(result);
        } catch (err) {
            winston.error('Internal Server Error ::: ExampleDelegate - delete', err);
            return Promise.reject(err);
        }
    }
}
